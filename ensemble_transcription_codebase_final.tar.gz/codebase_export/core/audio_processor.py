import librosa
import numpy as np
import ffmpeg
import tempfile
import os
import subprocess
from typing import Tuple, Optional

from utils.resilient_api import subprocess_retry
from core.circuit_breaker import CircuitBreakerOpenException
from utils.structured_logger import StructuredLogger

class AudioProcessor:
    """Handles audio extraction and preprocessing from video files"""
    
    def __init__(self, target_sr: int = 16000):
        self.target_sr = target_sr
        
        # Initialize structured logging for reliability telemetry
        self.structured_logger = StructuredLogger("audio_processor")
    
    @subprocess_retry
    def _ffmpeg_stream_copy_with_retry(self, input_path: str, output_path: str) -> subprocess.CompletedProcess:
        """
        Perform ffmpeg stream copy with retry logic and circuit breaker protection.
        
        Args:
            input_path: Path to input video file
            output_path: Path to output audio file
            
        Returns:
            subprocess.CompletedProcess result
            
        Raises:
            Various subprocess exceptions if ffmpeg fails after retries
        """
        return subprocess.run(
            [
                'ffmpeg', '-y', '-i', input_path, 
                '-vn',  # No video
                '-acodec', 'copy',  # Copy audio stream without re-encoding
                output_path
            ],
            capture_output=True,
            text=True,
            timeout=300  # 5 minute timeout for large files
        )
    
    @subprocess_retry
    def _ffmpeg_decode_to_wav_with_retry(self, input_path: str, output_path: str) -> subprocess.CompletedProcess:
        """
        Perform ffmpeg decode to ASR-ready WAV with retry logic.
        
        Args:
            input_path: Path to pristine audio file (e.g., .m4a)
            output_path: Path to output WAV file
            
        Returns:
            subprocess.CompletedProcess result
            
        Raises:
            Various subprocess exceptions if ffmpeg fails after retries
        """
        return subprocess.run(
            [
                'ffmpeg', '-y', '-i', input_path,
                '-ac', '1',  # Mono
                '-ar', str(self.target_sr),  # Target sample rate
                '-c:a', 'pcm_s16le',  # PCM 16-bit little-endian
                # Removed -t 5400 to support arbitrary length media without truncation
                output_path
            ],
            capture_output=True,
            text=True,
            timeout=1800  # 30 minute timeout for decode operations (increased for long media)
        )
    
    @subprocess_retry
    def _check_ffmpeg_with_retry(self) -> subprocess.CompletedProcess:
        """
        Check FFmpeg availability with retry logic and circuit breaker protection.
        
        Returns:
            subprocess.CompletedProcess result
            
        Raises:
            Various subprocess exceptions if FFmpeg check fails after retries
        """
        return subprocess.run(
            ['ffmpeg', '-version'],
            capture_output=True,
            text=True,
            timeout=10
        )
    
    def check_ffmpeg_availability(self) -> Tuple[bool, str]:
        """
        Check if FFmpeg is available and get version info.
        
        Returns:
            Tuple of (is_available, version_or_error_message)
        """
        try:
            # Use retry-protected method
            result = self._check_ffmpeg_with_retry()
            
            if result.returncode == 0:
                # Extract version from first line
                version_line = result.stdout.split('\n')[0]
                return True, version_line
            else:
                return False, f"FFmpeg returned error code {result.returncode}"
                
        except CircuitBreakerOpenException:
            return False, "FFmpeg service temporarily unavailable (circuit breaker open)"
        except FileNotFoundError:
            return False, "FFmpeg not found in system PATH"
        except subprocess.TimeoutExpired:
            return False, "FFmpeg command timed out after retries"
        except Exception as e:
            self.structured_logger.error(
                f"FFmpeg availability check failed after retries: {e}",
                context={'error_type': type(e).__name__, 'error_message': str(e)}
            )
            return False, f"Error checking FFmpeg: {str(e)}"
    
    @staticmethod
    def get_ffmpeg_install_instructions() -> str:
        """
        Get installation instructions for FFmpeg based on the environment.
        
        Returns:
            Installation instructions string
        """
        return """
**FFmpeg Installation Instructions:**

**For Replit:**
1. Add `ffmpeg` to your system dependencies in `pyproject.toml`:
   ```toml
   [build-system]
   requires = ["poetry-core"]
   build-backend = "poetry.core.masonry.api"
   
   [tool.poetry.dependencies]
   python = "^3.11"
   # ... other dependencies ...
   
   [tool.poetry.group.dev.dependencies]
   # Add this line:
   ffmpeg = "*"
   ```

2. Or use the Replit package manager:
   - Open the "Packages" tab in Replit
   - Search for "ffmpeg"
   - Click "Install"

**For local development:**
- **Ubuntu/Debian:** `sudo apt update && sudo apt install ffmpeg`
- **macOS:** `brew install ffmpeg`
- **Windows:** Download from https://ffmpeg.org/download.html

**Verification:**
Run `ffmpeg -version` in your terminal to verify installation.
        """
    
    def copy_audio_stream(self, video_path: str, output_path: Optional[str] = None) -> str:
        """
        Create pristine audio copy using ffmpeg stream copy to preserve original quality.
        This avoids any decode/encode artifacts that could corrupt audio for ASR services.
        
        Args:
            video_path: Path to input video file
            output_path: Optional custom output path for audio copy
            
        Returns:
            Path to pristine audio copy file
            
        Raises:
            Exception: If stream copy fails after retries
        """
        # Determine output format and path
        if output_path is None:
            # Create temporary file with appropriate extension
            audio_copy_fd, output_path = tempfile.mkstemp(suffix='_pristine.m4a')
            os.close(audio_copy_fd)  # Close file descriptor, keep path
        
        try:
            self.structured_logger.info(
                f"Starting audio stream copy: {video_path} -> {output_path}",
                context={'operation': 'stream_copy', 'input_path': video_path, 'output_path': output_path}
            )
            
            # Use retry-protected stream copy
            result = self._ffmpeg_stream_copy_with_retry(video_path, output_path)
            
            if result.returncode != 0:
                error_msg = f"FFmpeg stream copy failed (exit code {result.returncode}): {result.stderr}"
                self.structured_logger.error(error_msg, context={'stderr': result.stderr, 'stdout': result.stdout})
                
                # Attempt fallback to decode-only mode
                self.structured_logger.warning("Attempting fallback to decode-only mode")
                return self._fallback_decode_copy(video_path, output_path)
            
            # Verify output file was created and has content
            if not os.path.exists(output_path) or os.path.getsize(output_path) == 0:
                raise Exception(f"Stream copy produced empty or missing file: {output_path}")
            
            self.structured_logger.info(
                f"Audio stream copy completed successfully",
                context={'output_path': output_path, 'file_size': os.path.getsize(output_path)}
            )
            
            return output_path
            
        except CircuitBreakerOpenException:
            error_msg = "FFmpeg service temporarily unavailable (circuit breaker open)"
            self.structured_logger.error(error_msg)
            raise Exception(error_msg)
        except Exception as e:
            # Clean up on failure
            if os.path.exists(output_path):
                try:
                    os.unlink(output_path)
                except OSError:
                    pass
            
            error_msg = f"Audio stream copy failed: {str(e)}"
            self.structured_logger.error(error_msg, context={'error_type': type(e).__name__})
            raise Exception(error_msg)
    
    def _fallback_decode_copy(self, video_path: str, output_path: str) -> str:
        """
        Fallback method that decodes to high-quality audio when stream copy fails.
        
        Args:
            video_path: Input video path
            output_path: Desired output path
            
        Returns:
            Path to decoded audio file
        """
        try:
            # Use ffmpeg to decode to high-quality audio (not stream copy)
            result = subprocess.run(
                [
                    'ffmpeg', '-y', '-i', video_path,
                    '-vn',  # No video
                    '-acodec', 'aac',  # Use AAC encoding
                    '-b:a', '192k',  # High bitrate
                    '-ar', '48000',  # High sample rate
                    output_path
                ],
                capture_output=True,
                text=True,
                timeout=600
            )
            
            if result.returncode != 0:
                raise Exception(f"Fallback decode failed: {result.stderr}")
            
            self.structured_logger.info("Fallback decode completed successfully")
            return output_path
            
        except Exception as e:
            raise Exception(f"Both stream copy and fallback decode failed: {str(e)}")
    
    def make_asr_wav_from_audio(self, audio_path: str, output_path: Optional[str] = None) -> str:
        """
        Create ASR-ready WAV file from pristine audio copy.
        
        Args:
            audio_path: Path to pristine audio file (from copy_audio_stream)
            output_path: Optional custom output path for WAV file
            
        Returns:
            Path to ASR-ready WAV file
            
        Raises:
            Exception: If WAV creation fails after retries
        """
        # Create output path if not provided
        if output_path is None:
            wav_fd, output_path = tempfile.mkstemp(suffix='_asr_ready.wav')
            os.close(wav_fd)  # Close file descriptor, keep path
        
        try:
            self.structured_logger.info(
                f"Creating ASR-ready WAV: {audio_path} -> {output_path}",
                context={'operation': 'asr_wav_creation', 'input_path': audio_path, 'output_path': output_path}
            )
            
            # Use retry-protected decode to WAV
            result = self._ffmpeg_decode_to_wav_with_retry(audio_path, output_path)
            
            if result.returncode != 0:
                error_msg = f"FFmpeg WAV creation failed (exit code {result.returncode}): {result.stderr}"
                self.structured_logger.error(error_msg, context={'stderr': result.stderr, 'stdout': result.stdout})
                raise Exception(error_msg)
            
            # Verify output file was created and has content
            if not os.path.exists(output_path) or os.path.getsize(output_path) == 0:
                raise Exception(f"WAV creation produced empty or missing file: {output_path}")
            
            self.structured_logger.info(
                f"ASR-ready WAV created successfully",
                context={'output_path': output_path, 'file_size': os.path.getsize(output_path)}
            )
            
            return output_path
            
        except CircuitBreakerOpenException:
            error_msg = "FFmpeg service temporarily unavailable (circuit breaker open)"
            self.structured_logger.error(error_msg)
            raise Exception(error_msg)
        except Exception as e:
            # Clean up on failure
            if os.path.exists(output_path):
                try:
                    os.unlink(output_path)
                except OSError:
                    pass
            
            error_msg = f"ASR WAV creation failed: {str(e)}"
            self.structured_logger.error(error_msg, context={'error_type': type(e).__name__})
            raise Exception(error_msg)
    
    def extract_audio_from_video(self, video_path: str) -> Tuple[str, str]:
        """
        Extract audio from MP4 video file and create both pristine copy and ASR-ready versions.
        
        This method now uses a two-step process:
        1. Create pristine audio copy using stream copy (preserves quality)
        2. Create ASR-ready WAV from the pristine copy
        
        Args:
            video_path: Path to input MP4 file
            
        Returns:
            Tuple of (pristine_audio_path, asr_wav_path)
        """
        try:
            # Step 1: Create pristine audio copy using stream copy
            self.structured_logger.info(
                "Starting two-step audio extraction process",
                context={'input_video': video_path, 'operation': 'extract_audio_from_video'}
            )
            
            pristine_audio_path = self.copy_audio_stream(video_path)
            
            # Step 2: Create ASR-ready WAV from pristine copy
            asr_wav_path = self.make_asr_wav_from_audio(pristine_audio_path)
            
            # Get duration and validate full content was processed
            try:
                audio_duration = self.get_audio_duration(asr_wav_path)
                duration_hours = audio_duration / 3600
                
                # Log duration information for transparency
                if duration_hours >= 8:
                    self.structured_logger.warning(
                        f"Processed extremely long media: {duration_hours:.2f} hours - Full content preserved without truncation",
                        context={'duration_seconds': audio_duration, 'duration_hours': duration_hours}
                    )
                elif duration_hours >= 2:
                    self.structured_logger.info(
                        f"Processed long-form media: {duration_hours:.2f} hours - Full content preserved",
                        context={'duration_seconds': audio_duration, 'duration_hours': duration_hours}
                    )
                else:
                    self.structured_logger.info(
                        f"Processed media: {audio_duration/60:.1f} minutes - Full content preserved",
                        context={'duration_seconds': audio_duration, 'duration_minutes': audio_duration/60}
                    )
                    
            except Exception as duration_error:
                self.structured_logger.warning(f"Could not validate audio duration: {duration_error}")
            
            self.structured_logger.info(
                "Audio extraction completed successfully - No content truncation applied",
                context={
                    'pristine_audio': pristine_audio_path,
                    'asr_wav': asr_wav_path,
                    'pristine_size': os.path.getsize(pristine_audio_path),
                    'wav_size': os.path.getsize(asr_wav_path)
                }
            )
            
            return pristine_audio_path, asr_wav_path
            
        except Exception as e:
            error_msg = f"Audio extraction failed: {str(e)}"
            self.structured_logger.error(error_msg, context={'error_type': type(e).__name__, 'input_video': video_path})
            raise Exception(error_msg)
    
    def _preprocess_audio(self, audio_data: np.ndarray, sr: int) -> np.ndarray:
        """
        Apply light preprocessing to improve audio quality.
        
        Args:
            audio_data: Raw audio samples
            sr: Sample rate
            
        Returns:
            Preprocessed audio samples
        """
        # Trim silence from beginning and end (keep 0.5s buffer)
        trimmed_audio, _ = librosa.effects.trim(
            audio_data, 
            top_db=20,
            frame_length=2048,
            hop_length=512
        )
        
        # Add small buffer back
        buffer_samples = int(0.5 * sr)
        start_idx = max(0, len(audio_data) - len(trimmed_audio) - buffer_samples)
        end_idx = min(len(audio_data), start_idx + len(trimmed_audio) + 2 * buffer_samples)
        audio_data = audio_data[start_idx:end_idx]
        
        # Light noise reduction using spectral subtraction
        audio_data = self._spectral_subtraction(audio_data, sr)
        
        # Peak normalization (conservative)
        max_val = np.max(np.abs(audio_data))
        if max_val > 0:
            # Normalize to 85% of max to avoid clipping
            audio_data = audio_data * (0.85 / max_val)
        
        # Automatic gain control (very conservative)
        audio_data = self._apply_agc(audio_data, sr)
        
        return audio_data
    
    def _spectral_subtraction(self, audio_data: np.ndarray, sr: int, alpha: float = 2.0) -> np.ndarray:
        """
        Apply light spectral subtraction for noise reduction.
        
        Args:
            audio_data: Input audio samples
            sr: Sample rate
            alpha: Spectral subtraction factor
            
        Returns:
            Denoised audio samples
        """
        # STFT parameters
        n_fft = 2048
        hop_length = n_fft // 4
        
        # Compute STFT
        stft = librosa.stft(audio_data, n_fft=n_fft, hop_length=hop_length)
        magnitude = np.abs(stft)
        phase = np.angle(stft)
        
        # Estimate noise from first 1 second (assume initial noise)
        noise_frames = int(1.0 * sr / hop_length)
        noise_spectrum = np.mean(magnitude[:, :noise_frames], axis=1, keepdims=True)
        
        # Apply spectral subtraction
        clean_magnitude = magnitude - alpha * noise_spectrum
        
        # Ensure we don't go below 10% of original magnitude
        clean_magnitude = np.maximum(clean_magnitude, 0.1 * magnitude)
        
        # Reconstruct audio
        clean_stft = clean_magnitude * np.exp(1j * phase)
        clean_audio = librosa.istft(clean_stft, hop_length=hop_length)
        
        return clean_audio
    
    def _apply_agc(self, audio_data: np.ndarray, sr: int, 
                   target_rms: float = 0.15, window_size: float = 1.0) -> np.ndarray:
        """
        Apply automatic gain control to maintain consistent levels.
        
        Args:
            audio_data: Input audio samples
            sr: Sample rate  
            target_rms: Target RMS level
            window_size: AGC window size in seconds
            
        Returns:
            AGC-processed audio samples
        """
        window_samples = int(window_size * sr)
        hop_samples = window_samples // 4
        
        output_audio = audio_data.copy()
        
        for i in range(0, len(audio_data) - window_samples, hop_samples):
            window = audio_data[i:i + window_samples]
            current_rms = np.sqrt(np.mean(window ** 2))
            
            if current_rms > 0:
                gain = target_rms / current_rms
                # Limit gain to prevent artifacts
                gain = np.clip(gain, 0.5, 2.0)
                
                # Apply gain with smooth transition
                output_audio[i:i + window_samples] *= gain
        
        return output_audio
    
    
    def cleanup_temp_files(self, *file_paths: str) -> None:
        """
        Clean up temporary files safely.
        
        Args:
            *file_paths: Paths to temporary files to clean up
        """
        for path in file_paths:
            if path and os.path.exists(path):
                try:
                    os.unlink(path)
                    print(f"Cleaned up temp file: {path}")
                except OSError as e:
                    print(f"Warning: Could not clean up temp file {path}: {e}")
    
    def estimate_noise_level(self, audio_path: str) -> str:
        """
        Estimate the noise level in the audio file.
        
        Args:
            audio_path: Path to audio file
            
        Returns:
            Noise level category: 'low', 'medium', or 'high'
        """
        try:
            # Load first 30 seconds for analysis
            audio_data, sr = librosa.load(audio_path, sr=self.target_sr, duration=30.0)
            
            # Compute spectral centroid and bandwidth
            spectral_centroids = librosa.feature.spectral_centroid(y=audio_data, sr=sr)[0]
            spectral_bandwidth = librosa.feature.spectral_bandwidth(y=audio_data, sr=sr)[0]
            
            # Compute RMS energy
            rms = librosa.feature.rms(y=audio_data)[0]
            
            # Simple heuristic for noise level estimation
            avg_centroid = np.mean(spectral_centroids)
            avg_bandwidth = np.mean(spectral_bandwidth)
            avg_rms = np.mean(rms)
            
            # Thresholds based on typical speech characteristics
            if avg_centroid > 3000 and avg_bandwidth > 2500:
                return 'high'
            elif avg_centroid > 2000 and avg_bandwidth > 2000:
                return 'medium'
            else:
                return 'low'
                
        except Exception as e:
            print(f"Warning: Could not estimate noise level: {e}")
            return 'medium'  # Default fallback
    
    def get_audio_duration(self, audio_path: str) -> float:
        """
        Get duration of audio file in seconds.
        
        Args:
            audio_path: Path to audio file
            
        Returns:
            Duration in seconds
        """
        try:
            audio_data, sr = librosa.load(audio_path, sr=None)
            return len(audio_data) / sr
        except Exception as e:
            raise Exception(f"Could not determine audio duration: {str(e)}")
