import re
import math
from typing import Dict, Any, List, Set
from datetime import datetime, timedelta

class TranscriptFormatter:
    """Formats transcripts into various output formats (TXT, VTT, SRT, ASS)"""
    
    def __init__(self) -> None:
        self.speaker_colors: List[str] = [
            '#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7',
            '#DDA0DD', '#98D8C8', '#F7DC6F', '#BB8FCE', '#85C1E9'
        ]
    
    def create_txt_transcript(self, master_transcript: Dict[str, Any]) -> str:
        """
        Create plain text transcript with speaker names and timestamps.
        
        Args:
            master_transcript: Master transcript JSON
            
        Returns:
            Formatted text transcript
        """
        segments = master_transcript.get('segments', [])
        speaker_map = master_transcript.get('speaker_map', {})
        metadata = master_transcript.get('metadata', {})
        
        # Check if post-fusion punctuation was applied
        punctuation_metadata = master_transcript.get('punctuation_metadata', {})
        
        # Build header
        lines = []
        lines.append("=" * 60)
        lines.append("TRANSCRIPT")
        lines.append("=" * 60)
        lines.append("")
        
        # Add metadata
        lines.append(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        lines.append(f"Duration: {self.format_duration(metadata.get('total_duration', 0))}")
        lines.append(f"Segments: {metadata.get('total_segments', 0)}")
        lines.append(f"Speakers: {metadata.get('speaker_count', 0)}")
        lines.append("")
        
        # Add speaker roster
        if speaker_map:
            lines.append("PARTICIPANTS:")
            for speaker_id, speaker_name in speaker_map.items():
                lines.append(f"  • {speaker_name}")
            lines.append("")
        
        # Add confidence summary
        confidence_summary = metadata.get('confidence_summary', {})
        if confidence_summary:
            lines.append("CONFIDENCE SUMMARY:")
            lines.append(f"  • Overall Score: {confidence_summary.get('final_score', 0):.3f}")
            lines.append(f"  • Diarization: {confidence_summary.get('D_diarization', 0):.3f}")
            lines.append(f"  • ASR Alignment: {confidence_summary.get('A_asr_alignment', 0):.3f}")
            lines.append(f"  • Linguistic Quality: {confidence_summary.get('L_linguistic', 0):.3f}")
            lines.append(f"  • Cross-run Agreement: {confidence_summary.get('R_agreement', 0):.3f}")
            lines.append(f"  • Overlap Handling: {confidence_summary.get('O_overlap', 0):.3f}")
            lines.append("")
        
        # Add punctuation summary if available
        if punctuation_metadata:
            lines.append("PUNCTUATION PROCESSING:")
            lines.append(f"  • Punctuation Confidence: {punctuation_metadata.get('overall_confidence', 0):.3f}")
            lines.append(f"  • Normalization Level: {punctuation_metadata.get('normalization_level', 'N/A')}")
            
            punctuation_metrics = punctuation_metadata.get('punctuation_metrics', {})
            disfluency_metrics = punctuation_metadata.get('disfluency_metrics', {})
            
            if punctuation_metrics:
                lines.append(f"  • Segments Changed: {punctuation_metrics.get('segments_changed', 0)}")
            if disfluency_metrics:
                lines.append(f"  • Disfluency Normalized: {disfluency_metrics.get('segments_normalized', 0)}")
            
            model_info = punctuation_metadata.get('model_info', {})
            if model_info.get('model_available') == 'True':
                lines.append(f"  • Model: Transformer-based ({model_info.get('punctuation_model', 'Unknown')})")
            else:
                lines.append("  • Model: Rule-based (fallback)")
            
            lines.append("")
        
        lines.append("TRANSCRIPT:")
        lines.append("-" * 60)
        lines.append("")
        
        # Add transcript content
        current_speaker = None
        for segment in segments:
            timestamp = self.format_timestamp(segment['start'])
            speaker = segment['speaker']
            text = segment['text'].strip()
            
            if not text:
                continue
            
            # Add speaker change indicator
            if speaker != current_speaker:
                if current_speaker is not None:
                    lines.append("")  # Add blank line between speakers
                current_speaker = speaker
            
            # Check if segment has punctuation metadata for enhanced display
            if segment.get('punctuation_confidence') is not None:
                # Use punctuated text if confidence is high enough
                punct_confidence = segment.get('punctuation_confidence', 0)
                if punct_confidence > 0.5:  # Confidence threshold
                    # Show if disfluency normalization was applied
                    normalization_note = ""
                    if segment.get('disfluency_normalization_applied', False):
                        normalization_note = " [normalized]"
                    
                    lines.append(f"[{timestamp}] {speaker}: {text}{normalization_note}")
                    
                    # Optionally show original text if significantly different
                    original_text = segment.get('original_text', '')
                    if original_text and original_text.strip() != text.strip() and len(original_text) > 10:
                        text_diff = len(original_text) - len(text)
                        if abs(text_diff) > 5:  # Significant change threshold
                            lines.append(f"    [Original: {original_text.strip()[:100]}...]" if len(original_text) > 100 else f"    [Original: {original_text.strip()}]")
                else:
                    # Use original text if punctuation confidence is low
                    lines.append(f"[{timestamp}] {speaker}: {text}")
            else:
                # Standard display for segments without punctuation processing
                lines.append(f"[{timestamp}] {speaker}: {text}")
        
        # Add footer
        lines.append("")
        lines.append("-" * 60)
        lines.append("END OF TRANSCRIPT")
        lines.append("")
        lines.append("LEGEND:")
        lines.append("  [HH:MM:SS] - Timestamp")
        lines.append("  Speaker: - Speaker identification")
        lines.append("  Confidence scores range from 0.000 to 1.000")
        if punctuation_metadata:
            lines.append("  [normalized] - Disfluency normalization applied")
            lines.append("  [Original: ...] - Original text before punctuation/normalization")
        lines.append("")
        
        return '\n'.join(lines)
    
    def create_vtt_captions(self, master_transcript: Dict[str, Any]) -> str:
        """
        Create WebVTT captions with speaker positioning.
        
        Args:
            master_transcript: Master transcript JSON
            
        Returns:
            WebVTT formatted captions
        """
        segments = master_transcript.get('segments', [])
        
        lines = []
        lines.append("WEBVTT")
        lines.append("")
        lines.append("NOTE")
        lines.append("Generated by Advanced Ensemble Transcription System")
        lines.append("")
        
        # Assign positions to speakers
        speakers = list(set(seg['speaker'] for seg in segments))
        speaker_positions = {}
        positions = ["line:10%", "line:20%", "line:30%", "line:40%", "line:50%",
                    "line:60%", "line:70%", "line:80%", "line:90%"]
        
        for i, speaker in enumerate(speakers):
            if i < len(positions):
                speaker_positions[speaker] = positions[i]
            else:
                speaker_positions[speaker] = "line:50%"  # Default position
        
        # Generate cues
        for i, segment in enumerate(segments):
            text = segment['text'].strip()
            if not text:
                continue
            
            start_time = self.format_webvtt_time(segment['start'])
            end_time = self.format_webvtt_time(segment['end'])
            speaker = segment['speaker']
            position = speaker_positions.get(speaker, "line:50%")
            
            # Cue identifier
            lines.append(f"cue-{i+1}")
            lines.append(f"{start_time} --> {end_time} {position}")
            lines.append(f"<v {speaker}>{text}")
            lines.append("")
        
        return '\n'.join(lines)
    
    def create_srt_captions(self, master_transcript: Dict[str, Any]) -> str:
        """
        Create SRT captions with speaker names.
        
        Args:
            master_transcript: Master transcript JSON
            
        Returns:
            SRT formatted captions
        """
        segments = master_transcript.get('segments', [])
        
        lines = []
        cue_number = 1
        
        for segment in segments:
            text = segment['text'].strip()
            if not text:
                continue
            
            start_time = self.format_srt_time(segment['start'])
            end_time = self.format_srt_time(segment['end'])
            speaker = segment['speaker']
            
            lines.append(str(cue_number))
            lines.append(f"{start_time} --> {end_time}")
            lines.append(f"{speaker}: {text}")
            lines.append("")
            
            cue_number += 1
        
        return '\n'.join(lines)
    
    def create_ass_captions(self, master_transcript: Dict[str, Any]) -> str:
        """
        Create ASS captions with styled speaker differentiation.
        
        Args:
            master_transcript: Master transcript JSON
            
        Returns:
            ASS formatted captions
        """
        segments = master_transcript.get('segments', [])
        speakers = list(set(seg['speaker'] for seg in segments))
        
        lines = []
        
        # ASS header
        lines.append("[Script Info]")
        lines.append("Title: Ensemble Transcription")
        lines.append("ScriptType: v4.00+")
        lines.append("Collisions: Normal")
        lines.append("PlayDepth: 0")
        lines.append("")
        
        # Styles section
        lines.append("[V4+ Styles]")
        lines.append("Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding")
        
        # Create style for each speaker
        for i, speaker in enumerate(speakers):
            color = self.speaker_colors[i % len(self.speaker_colors)]
            # Convert hex to BGR format for ASS
            bgr_color = self._hex_to_bgr(color)
            
            lines.append(f"Style: {speaker},Arial,20,&H{bgr_color},&H000000,&H000000,&H80000000,0,0,0,0,100,100,0,0,1,2,0,2,10,10,10,1")
        
        lines.append("")
        
        # Events section
        lines.append("[Events]")
        lines.append("Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text")
        
        for segment in segments:
            text = segment['text'].strip()
            if not text:
                continue
            
            start_time = self.format_ass_time(segment['start'])
            end_time = self.format_ass_time(segment['end'])
            speaker = segment['speaker']
            
            # Escape special characters
            text = text.replace("\\", "\\\\").replace("{", "\\{").replace("}", "\\}")
            
            lines.append(f"Dialogue: 0,{start_time},{end_time},{speaker},,0,0,0,,{text}")
        
        return '\n'.join(lines)
    
    def format_timestamp(self, seconds: float) -> str:
        """Format seconds as HH:MM:SS timestamp"""
        hours = int(seconds // 3600)
        minutes = int((seconds % 3600) // 60)
        secs = int(seconds % 60)
        
        return f"{hours:02d}:{minutes:02d}:{secs:02d}"
    
    def format_duration(self, seconds: float) -> str:
        """Format duration in human-readable format"""
        hours = int(seconds // 3600)
        minutes = int((seconds % 3600) // 60)
        secs = int(seconds % 60)
        
        if hours > 0:
            return f"{hours}h {minutes}m {secs}s"
        elif minutes > 0:
            return f"{minutes}m {secs}s"
        else:
            return f"{secs}s"
    
    def format_webvtt_time(self, seconds: float) -> str:
        """Format time for WebVTT (HH:MM:SS.mmm)"""
        hours = int(seconds // 3600)
        minutes = int((seconds % 3600) // 60)
        secs = seconds % 60
        
        return f"{hours:02d}:{minutes:02d}:{secs:06.3f}"
    
    def format_srt_time(self, seconds: float) -> str:
        """Format time for SRT (HH:MM:SS,mmm)"""
        hours = int(seconds // 3600)
        minutes = int((seconds % 3600) // 60)
        secs = seconds % 60
        
        return f"{hours:02d}:{minutes:02d}:{secs:06.3f}".replace('.', ',')
    
    def format_ass_time(self, seconds: float) -> str:
        """Format time for ASS (H:MM:SS.cc)"""
        hours = int(seconds // 3600)
        minutes = int((seconds % 3600) // 60)
        secs = seconds % 60
        
        return f"{hours}:{minutes:02d}:{secs:05.2f}"
    
    def _hex_to_bgr(self, hex_color: str) -> str:
        """Convert hex color to BGR format for ASS"""
        hex_color = hex_color.lstrip('#')
        
        # Parse RGB
        r = int(hex_color[0:2], 16)
        g = int(hex_color[2:4], 16)
        b = int(hex_color[4:6], 16)
        
        # Convert to BGR hex
        bgr = f"{b:02X}{g:02X}{r:02X}"
        
        return bgr
    
    def create_segment_summary(self, master_transcript: Dict[str, Any]) -> Dict[str, Any]:
        """
        Create summary statistics for transcript segments.
        
        Args:
            master_transcript: Master transcript JSON
            
        Returns:
            Summary statistics dictionary
        """
        segments = master_transcript.get('segments', [])
        
        if not segments:
            return {'error': 'No segments found'}
        
        # Basic statistics
        total_segments = len(segments)
        total_duration = sum(seg['end'] - seg['start'] for seg in segments)
        total_words = sum(seg.get('word_count', 0) for seg in segments)
        
        # Speaker statistics
        speaker_stats = {}
        for segment in segments:
            speaker = segment['speaker']
            duration = segment['end'] - segment['start']
            word_count = segment.get('word_count', 0)
            
            if speaker not in speaker_stats:
                speaker_stats[speaker] = {
                    'segment_count': 0,
                    'total_duration': 0.0,
                    'total_words': 0,
                    'avg_confidence': []
                }
            
            speaker_stats[speaker]['segment_count'] += 1
            speaker_stats[speaker]['total_duration'] += duration
            speaker_stats[speaker]['total_words'] += word_count
            speaker_stats[speaker]['avg_confidence'].append(segment.get('confidence', 0.0))
        
        # Calculate averages
        for speaker in speaker_stats:
            confidences = speaker_stats[speaker]['avg_confidence']
            speaker_stats[speaker]['avg_confidence'] = sum(confidences) / len(confidences)
            speaker_stats[speaker]['speaking_percentage'] = (
                speaker_stats[speaker]['total_duration'] / total_duration * 100
            )
        
        # Segment length statistics
        segment_durations = [seg['end'] - seg['start'] for seg in segments]
        avg_segment_duration = sum(segment_durations) / len(segment_durations)
        
        summary = {
            'total_segments': total_segments,
            'total_duration': total_duration,
            'total_words': total_words,
            'avg_segment_duration': avg_segment_duration,
            'avg_words_per_segment': total_words / total_segments if total_segments > 0 else 0,
            'speaker_count': len(speaker_stats),
            'speaker_statistics': speaker_stats,
            'duration_formatted': self.format_duration(total_duration)
        }
        
        return summary
